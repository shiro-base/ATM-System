package Exceptions;

public class FancyBankException extends Exception{

    public FancyBankException(String msg){
        super(msg);
    }
}
