package StockMarket;

/*
interface for sellable items
 */
public interface Sellable {

    public void sell();
}
