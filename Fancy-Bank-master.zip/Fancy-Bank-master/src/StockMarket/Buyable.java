package StockMarket;

/*
interface for buyable items
 */
public interface Buyable {

    public void buy();
}
