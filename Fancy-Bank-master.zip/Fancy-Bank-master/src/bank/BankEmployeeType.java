/*
    enum class, to assign different type of BankEmployeeAbstract
 */
package bank;

public enum BankEmployeeType {
    MANAGER, EMPLOYEE
}
