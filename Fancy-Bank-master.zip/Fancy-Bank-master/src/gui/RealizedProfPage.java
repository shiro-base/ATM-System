package gui;
//CLASS FOR DISPLAYING REALIZED PROFIT
public class RealizedProfPage {
}
