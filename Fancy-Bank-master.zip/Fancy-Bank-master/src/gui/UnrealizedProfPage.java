package gui;

//CLASS FOR DISPLAYING UNREALIZED PROFITS
public class UnrealizedProfPage {
}
