import gui.LoginPage;

public class Main {
    public static void main(String[] args) throws Exception {
        LoginPage.main(args);
    }
}
